package ru.newyearhats;

import net.fabricmc.api.ModInitializer;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.server.command.CommandManager;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BoatItem;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.block.MapColor;
import net.minecraft.block.Blocks;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.entity.EquipmentSlot;

public class NewYearHats implements ModInitializer {
    public static final String MOD_ID = "new_year_hats";
    private static boolean snowfallEnabled = true;

    public static final Item SANTA_HAT = register("santa_hat");
    public static final Item BLUE_WINTER_HAT = register("blue_winter_hat");
    public static final Item ELF_HAT = register("elf_hat");
    public static final Item SNOW_HAT = register("snow_hat");
    public static final Item GOLDEN_HAT = register("golden_hat");
    public static final Item GARLAND = register("garland");
    public static final Item TREE_STAR = register("tree_star");
    public static final Item ORNAMENTS = register("ornaments");
    public static final Item OLIVIER = registerFood("olivier", 8, 0.8f);
    public static final Item HERRING_UNDER_COAT = registerFood("herring_under_coat", 9, 0.9f);
    public static final Item CRAB_SALAD = registerFood("crab_salad", 7, 0.7f);
    public static final Item VINAIGRETTE = registerFood("vinaigrette", 6, 0.6f);

    public static final net.minecraft.sound.SoundEvent NEW_YEAR_CAROL_SOUND = registerSound("new_year_carol");
    public static final net.minecraft.sound.SoundEvent WINTER_WALTZ_SOUND = registerSound("winter_waltz");
    public static final net.minecraft.sound.SoundEvent FIREWORKS_SOUND = registerSound("fireworks");
    public static final Item NEW_YEAR_CAROL_DISC = registerDisc("new_year_carol_disc", "new_year_carol");
    public static final Item WINTER_WALTZ_DISC = registerDisc("winter_waltz_disc", "winter_waltz");
    public static final Item FIREWORKS_DISC = registerDisc("fireworks_disc", "fireworks");

    public static final Item PAJAMA_HAT = registerWearable("pajama_hat", EquipmentSlot.HEAD);
    public static final Item PAJAMA_SHIRT = registerWearable("pajama_shirt", EquipmentSlot.CHEST);
    public static final Item PAJAMA_PANTS = registerWearable("pajama_pants", EquipmentSlot.LEGS);
    public static final Item PAJAMA_SLIPPERS = registerWearable("pajama_slippers", EquipmentSlot.FEET);
    // Functional first version: uses Minecraft's two-seat oak boat riding/steering behavior.
    public static final Item SLED = Registry.register(Registries.ITEM,
            Identifier.of(MOD_ID, "sled"),
            new BoatItem(BoatEntity.Type.OAK,
                    new Item.Settings().registryKey(RegistryKey.of(RegistryKeys.ITEM, Identifier.of(MOD_ID, "sled")))));
    public static final Block RED_GIFT = registerBlock("red_gift",
            AbstractBlock.Settings.create().mapColor(MapColor.RED).strength(0.5f).sounds(BlockSoundGroup.WOOL));
    public static final Block GREEN_GIFT = registerBlock("green_gift",
            AbstractBlock.Settings.create().mapColor(MapColor.GREEN).strength(0.5f).sounds(BlockSoundGroup.WOOL));
    public static final Block BLUE_GIFT = registerBlock("blue_gift",
            AbstractBlock.Settings.create().mapColor(MapColor.BLUE).strength(0.5f).sounds(BlockSoundGroup.WOOL));
    public static final Block SNOWMAN_BLOCK = registerBlock("snowman", new Block(AbstractBlock.Settings.create().registryKey(RegistryKey.of(RegistryKeys.BLOCK, Identifier.of(MOD_ID, "snowman"))).strength(0.5f).sounds(BlockSoundGroup.SNOW)));

    public static final Block DINING_TABLE = registerBlock("dining_table",
            AbstractBlock.Settings.create().mapColor(MapColor.OAK_TAN)
                    .strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final Block TABLECLOTH = registerBlock("tablecloth",
            AbstractBlock.Settings.create().mapColor(MapColor.RED)
                    .strength(0.5f).sounds(BlockSoundGroup.WOOL));
    public static final Block OLIVIER_PLATE = registerBlock("olivier_plate",
            AbstractBlock.Settings.create().mapColor(MapColor.LIME)
                    .strength(0.5f).sounds(BlockSoundGroup.WOOD));
    public static final Block HERRING_PLATE = registerBlock("herring_plate",
            AbstractBlock.Settings.create().mapColor(MapColor.PURPLE)
                    .strength(0.5f).sounds(BlockSoundGroup.WOOD));
    public static final Block CRAB_PLATE = registerBlock("crab_plate",
            AbstractBlock.Settings.create().mapColor(MapColor.ORANGE)
                    .strength(0.5f).sounds(BlockSoundGroup.WOOD));
    public static final Block VINAIGRETTE_PLATE = registerBlock("vinaigrette_plate",
            AbstractBlock.Settings.create().mapColor(MapColor.RED)
                    .strength(0.5f).sounds(BlockSoundGroup.WOOD));


    private static Item register(String name) {
        Identifier id = Identifier.of(MOD_ID, name);
        Item.Settings settings = new Item.Settings()
                .registryKey(RegistryKey.of(RegistryKeys.ITEM, id))
                .equippable(EquipmentSlot.HEAD);
        return Registry.register(Registries.ITEM, id, new Item(settings));
    }


    private static Block registerBlock(String name, AbstractBlock.Settings settings) {
        Identifier id = Identifier.of(MOD_ID, name);
        RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, id);
        Block block = new Block(settings.registryKey(blockKey));
        Registry.register(Registries.BLOCK, id, block);
        Item.Settings itemSettings = new Item.Settings()
                .registryKey(RegistryKey.of(RegistryKeys.ITEM, id));
        Registry.register(Registries.ITEM, id, new BlockItem(block, itemSettings));
        return block;
    }

    private static Item registerWearable(String name, EquipmentSlot slot) {
        Identifier id = Identifier.of(MOD_ID, name);
        Item.Settings settings = new Item.Settings()
                .registryKey(RegistryKey.of(RegistryKeys.ITEM, id))
                .equippable(slot);
        return Registry.register(Registries.ITEM, id, new Item(settings));
    }

    private static net.minecraft.sound.SoundEvent registerSound(String name) {
        Identifier id = Identifier.of(MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, net.minecraft.sound.SoundEvent.of(id));
    }

    private static Item registerDisc(String name, String songName) {
        Identifier id = Identifier.of(MOD_ID, name);
        RegistryKey<net.minecraft.block.jukebox.JukeboxSong> songKey =
                RegistryKey.of(RegistryKeys.JUKEBOX_SONG, Identifier.of(MOD_ID, songName));
        Item.Settings settings = new Item.Settings()
                .registryKey(RegistryKey.of(RegistryKeys.ITEM, id))
                .jukeboxPlayable(songKey);
        return Registry.register(Registries.ITEM, id, new Item(settings));
    }

    private static Item registerFood(String name, int nutrition, float saturation) {
        Identifier id = Identifier.of(MOD_ID, name);
        FoodComponent food = new FoodComponent.Builder()
                .nutrition(nutrition)
                .saturationModifier(saturation)
                .build();
        Item.Settings settings = new Item.Settings()
                .registryKey(RegistryKey.of(RegistryKeys.ITEM, id))
                .food(food);
        return Registry.register(Registries.ITEM, id, new Item(settings));
    }

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("nyhsnow")
                    .then(CommandManager.literal("on")
                            .executes(context -> {
                                snowfallEnabled = true;
                                context.getSource().sendFeedback(() -> Text.literal("Новогодний снег включён."), true);
                                return 1;
                            }))
                    .then(CommandManager.literal("off")
                            .executes(context -> {
                                snowfallEnabled = false;
                                context.getSource().sendFeedback(() -> Text.literal("Новогодний снег выключен."), true);
                                return 1;
                            }))
                    .then(CommandManager.literal("status")
                            .executes(context -> {
                                context.getSource().sendFeedback(
                                        () -> Text.literal("Новогодний снег: " + (snowfallEnabled ? "включён" : "выключен") + "."),
                                        false);
                                return 1;
                            })));
        });

        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (!snowfallEnabled || world.getPlayers().isEmpty() || world.getTime() % 2 != 0) {
                return;
            }
            for (var player : world.getPlayers()) {
                world.spawnParticles(ParticleTypes.SNOWFLAKE,
                        player.getX(), player.getY() + 7.0, player.getZ(),
                        18, 10.0, 5.0, 10.0, 0.015);
            }
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(entries -> {
            entries.add(SNOWMAN_BLOCK);
            entries.add(RED_GIFT);
            entries.add(GREEN_GIFT);
            entries.add(BLUE_GIFT);
            entries.add(DINING_TABLE);
            entries.add(TABLECLOTH);
            entries.add(OLIVIER_PLATE);
            entries.add(HERRING_PLATE);
            entries.add(CRAB_PLATE);
            entries.add(VINAIGRETTE_PLATE);
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(entries -> {
            entries.add(OLIVIER);
            entries.add(HERRING_UNDER_COAT);
            entries.add(CRAB_SALAD);
            entries.add(VINAIGRETTE);
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(NEW_YEAR_CAROL_DISC);
            entries.add(WINTER_WALTZ_DISC);
            entries.add(FIREWORKS_DISC);
            entries.add(SANTA_HAT);
            entries.add(BLUE_WINTER_HAT);
            entries.add(ELF_HAT);
            entries.add(SNOW_HAT);
            entries.add(GOLDEN_HAT);
            entries.add(PAJAMA_HAT);
            entries.add(PAJAMA_SHIRT);
            entries.add(PAJAMA_PANTS);
            entries.add(PAJAMA_SLIPPERS);
            entries.add(SLED);
            entries.add(GARLAND);
            entries.add(TREE_STAR);
            entries.add(ORNAMENTS);
        });
    }
}
